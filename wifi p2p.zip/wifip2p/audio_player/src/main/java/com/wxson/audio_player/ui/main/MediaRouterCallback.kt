package com.wxson.audio_player.ui.main

import android.media.MediaRouter

class MediaRouterCallback : MediaRouter.SimpleCallback() {
    override fun onRouteSelected(router: MediaRouter?, type: Int, info: MediaRouter.RouteInfo?) {
        super.onRouteSelected(router, type, info)
    }

    override fun onRouteUnselected(router: MediaRouter?, type: Int, info: MediaRouter.RouteInfo?) {
        super.onRouteUnselected(router, type, info)
    }

    override fun onRouteAdded(router: MediaRouter?, info: MediaRouter.RouteInfo?) {
        super.onRouteAdded(router, info)
    }

    override fun onRouteRemoved(router: MediaRouter?, info: MediaRouter.RouteInfo?) {
        super.onRouteRemoved(router, info)
    }

    override fun onRouteChanged(router: MediaRouter?, info: MediaRouter.RouteInfo?) {
        super.onRouteChanged(router, info)
    }

    override fun onRouteGrouped(router: MediaRouter?, info: MediaRouter.RouteInfo?, group: MediaRouter.RouteGroup?, index: Int) {
        super.onRouteGrouped(router, info, group, index)
    }

    override fun onRouteUngrouped(router: MediaRouter?, info: MediaRouter.RouteInfo?, group: MediaRouter.RouteGroup?) {
        super.onRouteUngrouped(router, info, group)
    }

    override fun onRouteVolumeChanged(router: MediaRouter?, info: MediaRouter.RouteInfo?) {
        super.onRouteVolumeChanged(router, info)
    }
}