package com.wxson.audio_player.ui.main

import android.media.MediaCodec
import android.media.MediaFormat
import android.util.Log

class CodecCallback {

    private val mediaCodecCallback = object : MediaCodec.Callback() {
        private val TAG = this.javaClass.simpleName

        override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {
            Log.i(TAG, "onInputBufferAvailable")
        }

        override fun onOutputBufferAvailable(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
            val outputBuffer = codec.getOutputBuffer(index)
            TODO("Not yet implemented")
        }

        override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
            Log.e(TAG, "onError")
        }

        override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
            Log.i(TAG, "onOutputFormatChanged")
        }
    }
}