audio_player
主要模块
CodecCallback：响应编解码器的各项异步事件
PlayerIntentService：远程连接服务
DirectBroadcastReceiver：处理wifi p2p事件的广播接收器
MediaRouter：媒体播放路由器，实现远程播放

MediaRouter实现远程播放有两种方式：远端播放和辅助输出
远端播放：
辅助输出：