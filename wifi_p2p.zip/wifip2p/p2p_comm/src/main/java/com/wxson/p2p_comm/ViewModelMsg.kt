package com.wxson.p2p_comm

data class ViewModelMsg(val type: Int, val obj: Any?)