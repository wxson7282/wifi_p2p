package com.wxson.audio_player.ui.main

enum class MsgType {
    DUMMY_PLAYER_PLAY,
    DUMMY_PLAYER_PAUSE,
    DUMMY_PLAYER_STOP,
    DUMMY_PLAYER_MUTE,
    DUMMY_PLAYER_RESUME,
    DUMMY_PLAYER_UNMUTE
}